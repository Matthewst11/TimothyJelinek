
public class CharacterDemo {

	public static void main(String[] args) {
		char initial = 'A';
		System.out.println(initial);
		System.out.print("\t\"abc\\def\bghi\n\njkl");

	}

}
