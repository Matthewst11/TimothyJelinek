<?php
include ("header.php");
include ("navigation.php");
?>
<h2>Our History</h2>
<p>
If you're reading this I know what you're thinking.  How did El Padre's Pizzeria begin?
Great question!  El Padre's Pizzera started as a thought in Saucey's head on Februrary 31st, 2013.  Saucey wanted to be their 
own boss while also serving their communinty.  They thought for hours about what their town needed. Then AHA!  The town needed a pizzeria!
A week later they started at the ground running trying to get their dream going.
</p>
<br>
<h3>Who Is Saucey?</h3>
<p>
Saucey is a respected individual in their community.  Whenever anyone wanted anything they went straight to Saucey.  Saucey was the person when 
it came to fundraisers.  There are annual fundraisers raising money for the school, church, and police department.
Saucey also has a cook off every Saturday where he enters his well known Saucey pizza.
</p>
<h3>What is Saucey's Pizzeria Known for?</h3>
<p>
Pizza of course!  El Padre's Pizzeria isn't just known for their pizza though, they also contribute towards scholarships, nursing homes,
schools, and local businesses.  El Padre's does giveaways frequently where they give gift certificates to random diners.  
</p>
<img src = "book.jpg"  alt = "A book" style = "width:15%; height:15%">
<?php
include ("footer.php");
?>