package unit2excercises;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class RandomGuessMatch {

	public static void main(String[] args) {
		Scanner inputDevice = new Scanner (System.in);
		System.out.println("Choose a number between 1 and 5." );
		int PersonGuess = inputDevice.nextInt();
		int random;
		random = (1+ (int)(Math.random() * 5));
		int diff =PersonGuess-random;
		
		
		if(diff==0)
			System.out.println("Your guess is right.");
			else 
				System.out.println("Your answer is incorrect.");
		System.out.println("Difference : "+diff);
		
		System.out.println("The number is " + random);
		
		inputDevice.close();
		
		
		
		
		
	}

}
