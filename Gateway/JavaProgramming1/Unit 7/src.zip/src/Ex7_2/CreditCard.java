package Ex7_2;

public class CreditCard {

	public static void main(String[] args) {
		

	}

}
