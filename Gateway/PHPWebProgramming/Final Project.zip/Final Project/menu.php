<?php
include ("header.php");
include ("navigation.php");
?>
<h2>What Is On The Menu For The Night!</h2>
<img src = "pizza2.jpg" alt = "Big Pizza Uncut" style = "float: right; width:12%; height:12%">
<p>Small Pizza: $4.99</p>
<p>Medium Pizza: $8.99</p>
<p>Large Pizza: $13.99</p>
<?php
include ("footer.php");
?>