# -*- coding: utf-8 -*-
"""
Created on Wed Sep 15 18:53:20 2021

@author: Tim
"""

print("Friends' Birthdays")
print("_____________________")
print("|Michael|  1/17/1998|")
print("|Connor |  2/28/1998|")
print("|Nick   |  6/20/1998|")
print("_____________________")