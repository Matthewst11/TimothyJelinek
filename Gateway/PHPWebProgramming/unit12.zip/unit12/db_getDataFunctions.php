<?php
// require_once will not include the file a second time if it has already been included
// require will halt script if this file cannot be included
require_once("database.php");
// Prepared statement inside a function to
// select all records from games table
function getGameInventory(){
    $queryCategory = 'SELECT * FROM games';
    // $GLOBALS[] PHP stores all global variables in this array
    // 'db' is the name of the global $db variable from database connection
    $statement1 = $GLOBALS['db']->prepare($queryCategory);
    $statement1->execute();
    $gameInventory = $statement1->fetchAll();
    $statement1->closeCursor();
    return $gameInventory;
}

function getGame($game) {
    $queryGame = 'SELECT * FROM games where gameTitle = game';
    $statement1 = $GLOBALS['db']->prepare($queryGame);
    $statement1->bindValue(':game', $game);
    $statement1->execute();
    $game = $statement1->fetchAll();
    return $game[0];
}

function getCustomers() {
    $queryAllCustomers = 'SELECT * FROM customer';
    $statement2 = $GLOBALS['db']->prepare($queryAllCustomers);
    $statement2->execute();
    $customers = $statement2->fetchAll();
    $statement2->closeCurrent();
    return $customers;
}

function addCustomer($name, $email) {
    // Add customer to the database
    $query = 'INSERT INTO customer(name, email)
              VALUES(:name, :email)';
    $statement = $GLOBALS['db']->prepare($query);
    $statement->bindValue(':name', $name);
    $statement->bindValue(':email', $email);
    $statement->execute();
    $statement->closeCursor();
}
?>