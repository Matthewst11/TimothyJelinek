import java.util.Scanner;

public class Eggs {


	public static void main(String[] args) {
		Scanner inputDevice = new Scanner (System.in);
		System.out.println("Please insert a number of eggs.");
		int NumberOfEggs = inputDevice.nextInt();
		
		
		System.out.println("You ordered " + NumberOfEggs + "eggs.");
		System.out.print(" That's "+ NumberOfEggs/12 + " dozen at $3.25 per dozen and ");
		System.out.print(NumberOfEggs%12 + " loose eggs at 45 cents each for a total of $");
		System.out.print(NumberOfEggs/12*3.25 + NumberOfEggs%12*0.45);
		
		inputDevice.close();
		
		
	}

}
