import java.util.Scanner;

public class DistanceFromAverage {

	public static void main(String[] args) {
		

	}

}
