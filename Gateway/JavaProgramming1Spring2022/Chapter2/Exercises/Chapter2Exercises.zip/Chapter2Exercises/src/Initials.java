
public class Initials {

	public static void main(String[] args) {
		char f = 'T';
		char m = 'A';
		char l = 'J';
				
		System.out.println("Your initials are: " + f +"." + m + "." + l);
	}

}
