import javax.swing.JOptionPane;

public class Comments {

		public static void main(String[] args) {
			System.out.println("Program comments are nonexecuting )"
					+ "statements you add to a file for documentation."); // comment

			//Program comments are nonexecuting statements you add to a file for documentation.
			
			/*Program comments are nonexecuting statements you add to a file for documentation.
			 * 
			 */
			
	}

}
