package ex7;

public class moviequote {
	public static void main(String[] args) {
		System.out.println("\"Do or Do Not,");
		System.out.println("There is no try.\"");
		System.out.println("Quote by Yoda");
		System.out.println("Star Wars V 1980");
	}
}
