
public class MilesConversion {

	public static void main(String[] args) {
		final int INCHES_PER_MILE = 63360;
		final int FEET_PER_MILE = 5280;
		final int YARDS_PER_MILE = 1760;
		int miles = 100;
		
		System.out.println("There are: " + INCHES_PER_MILE * miles + " inches in " + miles + " miles");
		System.out.println("There are: " + FEET_PER_MILE * miles + " feet in " + miles + " miles");
		System.out.println("There are: " + YARDS_PER_MILE * miles + " yards in " + miles + " miles");

	}

}
