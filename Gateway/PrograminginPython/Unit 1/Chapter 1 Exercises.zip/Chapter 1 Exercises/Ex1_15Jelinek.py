# -*- coding: utf-8 -*-
"""
Created on Wed Sep 15 18:57:55 2021

@author: Tim
"""

print("Sales Tax Rates  ")
print("-----------------")
print("Illinois:   6.25%")
print("Texas:      6.25%")
print("California: 7.25%")
print("Florida:    6.00%")
print("Iowa:       6.00%")