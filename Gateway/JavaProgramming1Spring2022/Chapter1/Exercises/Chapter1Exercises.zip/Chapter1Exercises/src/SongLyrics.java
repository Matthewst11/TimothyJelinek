
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("I'mma put in work, I'mma do that ASAP");
		System.out.println("Throw my faith in rap, but they say don't say that huh?");
		System.out.println("What I'mma turn down for, I feel like Shaq in nine four");
		System.out.println("Breaking glass in that backboard, or like Kobe in Toronto, huh?");
	}

}
