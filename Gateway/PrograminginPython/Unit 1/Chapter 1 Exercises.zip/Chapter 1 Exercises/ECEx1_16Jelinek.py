# -*- coding: utf-8 -*-
"""
Created on Wed Sep 15 19:34:44 2021

@author: Tim
"""

print("__________________________________________________________")
print("|English                      | Spanish                |")
print("|------------------------------------------------------- |")
print("|Good Morning.                | Buenos Días.             |")
print("|It is a pleasure to meet you.| Es un placer conocerte.  |")
print("|Please call me tomorrow.     | Por favor llámame mañana.|")
print("|Have a nice day!             | ¡Que tenga un lindo día! |")
print("---------------------------------------------------------|")