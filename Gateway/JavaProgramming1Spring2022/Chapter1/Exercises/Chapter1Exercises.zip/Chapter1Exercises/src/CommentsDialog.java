import javax.swing.JOptionPane; 

public class CommentsDialog {

	public static void main(String[] args) { // here is that other one
		JOptionPane.showMessageDialog(null,"Program comments are nonexecuting "
					+ "statements you add to a file for documentation."); // comment

			//Program comments are nonexecuting statements you add to a file for documentation.
			
			/*Program comments are nonexecuting statements you add to a file for documentation.
			 * 
			 */
			

	}

}
