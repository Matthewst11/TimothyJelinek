import java.util.Scanner;

public class InchesToFeetInteractive {

	public static void main(String[] args) {
		
		final int INCHES_PER_FOOT = 12;
		int inches = 72;
		int feet;
		int extraInches;
		
		
		Scanner input = new Scanner(System.in);
		System.out.print("Please enter number of inches >> ");
		inches = input.nextInt();
		
		feet = inches / INCHES_PER_FOOT;
		extraInches = inches % INCHES_PER_FOOT;
		
		System.out.println(inches + "inches is " + feet + " feet and " + extraInches + " inches");

	}

}
