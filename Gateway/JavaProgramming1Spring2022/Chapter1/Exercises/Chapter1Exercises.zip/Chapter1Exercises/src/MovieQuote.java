
public class MovieQuote {

	public static void main(String[] args) {
		System.out.println("Quote: 'Do or Do Not,");
		System.out.println("There is no try.'");
		System.out.println("Character: Yoda");
		System.out.println("Movie: Star Wars V 1980");
		System.out.println("Year: 1980");
	}

}
