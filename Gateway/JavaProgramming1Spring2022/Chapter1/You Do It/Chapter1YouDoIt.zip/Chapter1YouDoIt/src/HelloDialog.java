// Filename HelloDialog.java
// Timothy Jelinek
// 2/1/22

import javax.swing.JOptionPane; 

public class HelloDialog {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Hello, world!");

	}

}
