
public class TestInfo {

	public static void main(String[] args) {
		System.out.println("This example below is a call to an external program:");
		ParadiseInfo.displayInfo();

	}

}
