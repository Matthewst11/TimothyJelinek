package ex8;

public class TableChairs {
	public static void main(String[] args) {
		System.out.println("X                      X");
		System.out.println("X                      X");
		System.out.println("X      XXXXXXXXXX      X");
		System.out.println("XXXXX  X        X  XXXXX");
		System.out.println("X   X  X        X  X   X");
		System.out.println("X   X  X        X  X   X");
	}
}
