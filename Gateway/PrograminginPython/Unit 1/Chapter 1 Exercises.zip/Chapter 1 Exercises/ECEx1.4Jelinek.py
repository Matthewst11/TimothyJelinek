# -*- coding: utf-8 -*-
"""
Created on Wed Sep 15 19:21:02 2021

@author: Tim
"""

print("First year balance:  $1,000.00")
print("Second year balance: $1,050.00")
print("Third year balance:  $1,102.50")
