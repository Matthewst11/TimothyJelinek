# -*- coding: utf-8 -*-
"""
Created on Wed Oct 13 12:49:06 2021

@author: Tim
"""

#get input from user
num = int(input("Enter an Integer: "))

#decide what the number is and display
if num > 0 : 
    print("The number is positive.")
elif num == 0 :
    print("The number is zero.")
else : 
    print("The number is negative.")

