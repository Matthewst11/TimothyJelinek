import java.util.Scanner;

public class QuartsToGallonsInteractive {

	public static void main(String[] args) {
		final int QUARTS_IN_GALLON = 4;
		int quartsTotal;
		int gallonsNeeded;
		int quartsNeeded;
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Please enter the number of quarts of paint needed  >> ");
		quartsTotal = input.nextInt();
		
		gallonsNeeded = quartsTotal / QUARTS_IN_GALLON;
		quartsNeeded = quartsTotal % QUARTS_IN_GALLON;
		
		System.out.println("A job that needs " + quartsTotal + " quarts, requires " 
				+ gallonsNeeded + " gallons plus " + quartsNeeded + " quarts.");

		input.close();
	}

	
}
