<!DOCTYPE html>
<html lang="en">
<head>
<title>Potluck Registration</title>
<meta charset="UTF-8"/>
<link rel="stylesheet" href="main.css">
</head>
<body>
<main>