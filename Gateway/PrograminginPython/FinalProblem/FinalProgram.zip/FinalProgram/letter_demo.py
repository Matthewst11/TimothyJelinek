from letter import Letter


letter=Letter("Mary","John")
letter.addLine("I am sorry we must part.")
letter.addLine("I wish you all the best.")
print(letter.getText())
