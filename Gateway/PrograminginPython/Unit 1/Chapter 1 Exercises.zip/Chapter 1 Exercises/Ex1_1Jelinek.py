# -*- coding: utf-8 -*-
"""
Created on Wed Sep 15 14:19:11 2021

@author: Tim
"""

print("Greetings from Kenosha - It is a beautiful day today.")