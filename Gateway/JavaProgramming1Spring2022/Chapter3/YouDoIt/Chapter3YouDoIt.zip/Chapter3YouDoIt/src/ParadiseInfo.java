
public class ParadiseInfo {

	public static void main(String[] args) {
		
		displayInfo();

	}

	public static void displayInfo() {
		System.out.println("Paradise Day Spa wants to pamper you.");
		System.out.println("We will make you look good.");
		
		
	}

}
