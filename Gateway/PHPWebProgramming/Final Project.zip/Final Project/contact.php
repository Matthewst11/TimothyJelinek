<?php
include ("header.php");
include ("navigation.php");
?>
<h2>How to Contact Us:</h2>
<img src = "contact.png" alt = "Contact options" style = "width:25%; height:25%">
<P>Our Address is 1555 Main ST, Pizza Blvd, PA 55555</p>
<p>Our Phone Number is (555)555-5555</p>
<p>Our Email is padrepizza@pizzapadre.com</p>
<?php
include ("footer.php");
?>