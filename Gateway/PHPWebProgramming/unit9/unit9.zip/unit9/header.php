<!DOCTYPE html>
<html lang="en">
<head>
<title>Games form</title>
<meta charset="UTF-8"/>
<link rel="stylesheet" href="main.css">
</head>
<body>
<main>