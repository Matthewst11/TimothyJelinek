# -*- coding: utf-8 -*-
"""
Created on Wed Sep 15 14:30:32 2021

@author: Tim
"""

print(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10)
