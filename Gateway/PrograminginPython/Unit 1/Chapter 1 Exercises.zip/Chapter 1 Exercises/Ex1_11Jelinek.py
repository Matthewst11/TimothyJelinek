# -*- coding: utf-8 -*-
"""
Created on Wed Sep 15 18:46:52 2021

@author: Tim
"""

print("Michael")
print("Connor")
print("Nick")