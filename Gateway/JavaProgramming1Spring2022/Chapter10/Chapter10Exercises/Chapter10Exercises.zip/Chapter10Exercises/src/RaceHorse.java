
public class RaceHorse extends Horse {
	private int races;

	public int getRaces() {
		return races;
	}

	public void setRaces(int races) {
		this.races = races;
	}
	
	
}
