# -*- coding: utf-8 -*-
"""
Created on Wed Sep 15 14:33:11 2021

@author: Tim
"""

print("*******   *******   *        *")
print("   *         *      * *    * *")
print("   *         *      *  *  *  *")
print("   *         *      *   **   *")
print("   *      *******   *    *   *")