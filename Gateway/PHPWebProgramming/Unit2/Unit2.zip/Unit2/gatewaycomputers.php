<!DOCTYPE html>
<html lang="en">
<head>
<title>Beginning of the Semester Sale</title>
<meta charset="UTP-8"/>
</head>
<body>
<?php include("inc_header.php");?>    
<ul> <li>Lenovo Notebook: <strong>$799.99</strong></li>
    <li>Epson Color All-In-One Printer, Print/Copy/Scan: <strong>$699.99</strong></li>
    <li>LG 24-inch LCD Monitor, Silver/Black: <strong>$199.99</strong></li>
    <li>Hawking Technology Hi-Speed Wireless-G Cardbus Card: <strong>$9.99</strong></li>
</ul>
<?php include("inc_footer.php")?>
</body>
</html>