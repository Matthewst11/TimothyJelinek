
public class SpaService {
	private String serviceDescription;
	private double price;
	
	public SpaService() {
		serviceDescription = "XXX";
		price = 0;
	}
	
	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
