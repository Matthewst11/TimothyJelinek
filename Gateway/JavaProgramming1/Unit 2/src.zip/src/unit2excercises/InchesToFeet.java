package unit2excercises;

public class InchesToFeet {

	public static void main(String[] args) {
		
		final int INCHES_PER_FOOT = 12;
		
		int inches = 72;
		
		int feet;
		
		int extraInches;
		
		feet = inches / INCHES_PER_FOOT;
		
		extraInches = inches % INCHES_PER_FOOT;
		
		System.out.println(inches + "inches is " + feet + "feet and " + extraInches + " inches");
		
		
		

	}

}
