<nav>
	<ul>
	<li><a href="index.php">Home</a></li> 
	<li><a href="history.php">History</a></li>
	<li><a href="menu.php">Menu</a></li>
	<li><a href="contact.php">Contact Us</a></li>
	<li><a href="newsletter.php">Newsletter</a></li>
	</ul>
<hr>
</nav>