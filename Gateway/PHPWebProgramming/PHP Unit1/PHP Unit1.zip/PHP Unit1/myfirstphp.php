<!DOCTYPE html>
<html>
	<head>
		<title> My First PHP Page</title>
	</head>
	<body>
	<h1><?php 
	echo "This is my first PHP page!";
	?></h1>
	<p><?php 
	echo "by Timothy Jelinek";
	?>
	</p>
	<footer><?php
	echo "©2020 Your Name. PHP Web Programming.";
	?>
	</footer>
	</body>
</html>
