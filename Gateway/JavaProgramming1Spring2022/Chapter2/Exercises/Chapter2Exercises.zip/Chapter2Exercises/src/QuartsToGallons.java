
public class QuartsToGallons {

	public static void main(String[] args) {
		final int QUARTS_IN_GALLON = 4;
		int quartsTotal = 18;
		int gallonsNeeded;
		int quartsNeeded;
		
		gallonsNeeded = quartsTotal / QUARTS_IN_GALLON;
		quartsNeeded = quartsTotal % QUARTS_IN_GALLON;
		
		System.out.println("A job that needs " + quartsTotal + " quarts, requires " 
		+ gallonsNeeded + " gallons plus " + quartsNeeded + " quarts.");

	}

}
