
public class UseDinnerPartyWithConstructor {

	public static void main(String[] args) {
		DinnerPartyWithConstructor aDinnerParty = new DinnerPartyWithConstructor();

	}

}
