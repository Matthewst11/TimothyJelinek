<!DOCTYPE html>
<html lang="en">
<head>
<title>El Padre's Pizzeria</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="finalproject.css">
<meta name="description" content="This site has everything you need to know about El Padre's Pizzeria.">
</head>
<body>
<header>
<img src = "pizza.jpg" alt = "Dancing pizza" style = "float: right; width:15%; height:15%">
<h1><a href="index.php">El Padre's Pizzeria!</a></h1>
</header>
<main>