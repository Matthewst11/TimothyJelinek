# -*- coding: utf-8 -*-
"""
Created on Wed Sep 15 18:49:13 2021

@author: Tim
"""

print("To evrything there is a season,")
print("and a time to every purpose under the heaven:")
print("A time to be born, and a time to die;")
print("a time to plant, and a time to reap...")