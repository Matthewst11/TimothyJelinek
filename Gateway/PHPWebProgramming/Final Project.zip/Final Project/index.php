<?php
include ("header.php");
include ("navigation.php");
include ("main.php");
include ("footer.php");
?>