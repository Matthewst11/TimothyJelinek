package ex10;
/** Program comments are nonexecuting statements you add to a file for documentation.
 *
 */
public class comment {
	/* Program comments are nonexecuting statements you add to a file for documentation.
	 * 
	 */
	
	public static void main(String[] args) {
		// Program comments are nonexecuting statements you add to a file for documentation.
		
		System.out.println("Program comments are nonexecuting statements you add to a file for documentation.");
		
		
	}

}
