<h2>The Secret Behind The Pizza</h2>

<h4 style = "color:red">More Sauce!</h4>
<p>
We strive to have the best pizzas around!  In our opinion the best thing about pizza is the sauce.  
Our founder, Saucey, thinks he has the perfect amount of sauce figured out!  There are also other ingredients in our sauce, 
but those are for you to find out!
</p>
<br>
<img src = "cheesepizza.jpg" alt = "Cheese pizza" style = "float: right; width:15%; height:15%">
<h4 style = "color:yellow">Light Cheese!</h4>
<p>
When we added more of one great thing, we had to take away from another.  Our pizzas have only the best cheese on them!  
Too much of a good thing can be a bad thing, so Saucey worked hard on figuring out just the right amount of cheese.  
You can't go wrong with our sauce and cheese combination! 
</p>
<br>
<h4 style = "color: green">Peppers</h4>
<p>
Another ingredient?  That's right!  We have the best peppers on our pizza.  Our peppers are not too spicy and not too mild.  
They're just right.
</p>